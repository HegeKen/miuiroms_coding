<?php

for($i=1;$i<=999;$i++){
    echo "第".sprintf("%03d",$i)."周：\n";
}
