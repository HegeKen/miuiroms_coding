<?php
for($i=431;$i<=500;$i++){
    echo "第".$i."周：";
    echo "\n";
}